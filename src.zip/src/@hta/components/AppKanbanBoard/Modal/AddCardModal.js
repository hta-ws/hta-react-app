import React, { useState } from 'react';
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  FormGroup,
  Label,
  Input,
} from 'reactstrap';
import WidgetForm from './WidgetForm';
import TableForm from './TableForm';
import ChartForm from './ChartForm';

const AddCardModal = ({ isOpen, toggle, onSubmit }) => {
  const [selectedType, setSelectedType] = useState('');
  const [title, setTitle] = useState('');

  const handleTypeChange = (e) => {
    setSelectedType(e.target.value);
  };

  const handleTitleChange = (e) => {
    setTitle(e.target.value);
  };

  const handleCancel = () => {
    setSelectedType('');
    setTitle('');
    toggle();
  };

  const renderForm = () => {
    const initialValues = { type: selectedType, title };
    switch (selectedType) {
      case 'widget':
        return (
          <WidgetForm
            initialValues={initialValues}
            onSubmit={onSubmit}
            onCancel={handleCancel}
          />
        );
      case 'table':
        return (
          <TableForm
            initialValues={initialValues}
            onSubmit={onSubmit}
            onCancel={handleCancel}
          />
        );
      case 'chart':
        return (
          <ChartForm
            initialValues={initialValues}
            onSubmit={onSubmit}
            onCancel={handleCancel}
          />
        );
      default:
        return null;
    }
  };

  return (
    <Modal isOpen={isOpen} toggle={toggle}>
      <ModalHeader toggle={toggle}>Yeni Kart Ekle</ModalHeader>
      <ModalBody>
        <FormGroup>
          <Label for='title'>Başlık</Label>
          <Input
            type='text'
            name='title'
            id='title'
            value={title}
            onChange={handleTitleChange}
          />
        </FormGroup>
        <FormGroup>
          <Label for='type'>Tip Seçin</Label>
          <Input
            type='select'
            name='type'
            id='type'
            value={selectedType}
            onChange={handleTypeChange}
          >
            <option value=''>Seçiniz</option>
            <option value='widget'>Widget</option>
            <option value='table'>Tablo</option>
            <option value='chart'>Grafik</option>
          </Input>
        </FormGroup>
        {renderForm()}
      </ModalBody>
      <ModalFooter>
        <Button color='secondary' onClick={handleCancel}>
          İptal
        </Button>
      </ModalFooter>
    </Modal>
  );
};

export default AddCardModal;
