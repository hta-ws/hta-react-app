import enMessages from '../locales/en_US.json';

const EnLang = {
  messages: {
    ...enMessages,
  },
  muiLocale: 'ee',
  locale: 'en-US',
};
export default EnLang;
