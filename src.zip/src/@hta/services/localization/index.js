import enLang from './entries/en-US';

const AppLocale = {
  en: enLang,
};

export default AppLocale;
