import React from 'react';

const FormView = () => {
  return (
    <div>
      <h1>FormView</h1>
    </div>
  );
};

export default FormView;
