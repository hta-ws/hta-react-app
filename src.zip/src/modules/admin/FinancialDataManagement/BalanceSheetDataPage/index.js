import React from 'react';

const BalanceSheetDataPage = () => {
  return <div>BalanceSheetDataPage</div>;
};

export default BalanceSheetDataPage;
