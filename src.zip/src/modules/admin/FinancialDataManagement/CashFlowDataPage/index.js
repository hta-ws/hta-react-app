import React from 'react';

const CashFlowDataPage = () => {
  return <div>CashFlowDataPage</div>;
};

export default CashFlowDataPage;
