import React from 'react';

const IncomeStatementDataPage = () => {
  return <div>IncomeStatementDataPage</div>;
};

export default IncomeStatementDataPage;
