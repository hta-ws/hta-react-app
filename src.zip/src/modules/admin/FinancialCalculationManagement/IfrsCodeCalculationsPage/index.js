import React from 'react';

const IfrsCodeCalculationsPage = () => {
  return <div>IfrsCodeCalculationsPage</div>;
};

export default IfrsCodeCalculationsPage;
