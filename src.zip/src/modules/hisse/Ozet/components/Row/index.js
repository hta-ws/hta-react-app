import React from 'react';

const Row = () => {
  return <div>index</div>;
};

export default Row;
